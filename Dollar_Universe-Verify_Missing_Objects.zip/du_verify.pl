### =============================================================================== ###
### This script verify the consistency of Dollar Universe 6 Nodes                   ###
### Argument list                                                                   ###
### - 1: Area: APP, SIM, INT, EXP                                                   ###
### - 2: Node: (optional the default is the current node                            ###
### =============================================================================== ###

### =============================================================================== ###
### Lib required ###




### =============================================================================== ###
### Parameters ###
my $nb_arg=scalar @ARGV;
my $AREA_FILTER = "";
my $NODE_FILTER = "";
if ($nb_arg>0) {
    $AREA_FILTER = $ARGV[0];
}
if ($nb_arg>1) {
    $NODE_FILTER = "node=".$ARGV[1];
}
# Global context for the commands
$GCTX=" ".$AREA_FILTER." ".$NODE_FILTER;




### =============================================================================== ###
### Main procedure ###

# Intro
print("\n");
print(" Checking Configuration...");
if ($NODE_FILTER eq "") {
    print("  Local node ");
} else {
    print("  ".$NODE_FILTER);
}
if ($AREA_FILTER eq "") {
    print(" / area: EXP");
} else {
    print(" / area: ".$AREA_FILTER);
}
print("\n");
print("\n");


# Init temporary files
my $TEMP_DIR = $ENV{'U_TMP_PATH'};

# Get the uxshw
uxshw_store("APPL APPL=*",$TEMP_DIR."/appl_shw");
uxshw_store("CAL MU=*",$TEMP_DIR."/cal_shw");
uxshw_store("HDP MU=* DEPMU=*",$TEMP_DIR."/hdp_shw");
uxshw_store("MU MU=*",$TEMP_DIR."/mu_shw");
uxshw_store("SES SES=*",$TEMP_DIR."/ses_shw");
uxshw_store("SES SES=* LNK",$TEMP_DIR."/ses_shw_lnk");
uxshw_store("TSK TSK=* MU=* SES=*",$TEMP_DIR."/tsk_shw");
uxshw_store("UPR UPR=*",$TEMP_DIR."/upr_shw");

# Object type by object type, get the list of dependant object
list_dependencies($TEMP_DIR."/appl_shw","| dom ",$TEMP_DIR."/dom");
list_dependencies($TEMP_DIR."/cal_shw","| mu ",$TEMP_DIR."/mu");
list_dependencies($TEMP_DIR."/hdp_shw","| mu ",$TEMP_DIR."/mu");
list_dependencies($TEMP_DIR."/hdp_shw","| depmu ",$TEMP_DIR."/mu");
list_dependencies($TEMP_DIR."/mu_shw","| tnode ",$TEMP_DIR."/node");
list_dependencies($TEMP_DIR."/ses_shw","| upr ",$TEMP_DIR."/upr");
list_dependencies_session($TEMP_DIR."/ses_shw_lnk",$TEMP_DIR."/mu");
list_dependencies($TEMP_DIR."/tsk_shw","| upr ",$TEMP_DIR."/upr");
list_dependencies($TEMP_DIR."/tsk_shw","| ses ",$TEMP_DIR."/ses");
list_dependencies($TEMP_DIR."/tsk_shw","| mu ",$TEMP_DIR."/mu");
list_dependencies($TEMP_DIR."/tsk_shw","| user ",$TEMP_DIR."/user");
list_dependencies($TEMP_DIR."/upr_shw"," dep          : ",$TEMP_DIR."/upr");
list_dependencies($TEMP_DIR."/upr_shw"," res          : ",$TEMP_DIR."/res");
list_dependencies($TEMP_DIR."/upr_shw","| mu ",$TEMP_DIR."/mu");
list_dependencies($TEMP_DIR."/upr_shw","| class ",$TEMP_DIR."/class");
list_dependencies($TEMP_DIR."/upr_shw","| appl ",$TEMP_DIR."/appl");

# Remove duplicates
file_remove_duplicates($TEMP_DIR."/appl");
file_remove_duplicates($TEMP_DIR."/class");
file_remove_duplicates($TEMP_DIR."/dom");
file_remove_duplicates($TEMP_DIR."/mu");
file_remove_duplicates($TEMP_DIR."/node");
file_remove_duplicates($TEMP_DIR."/res");
file_remove_duplicates($TEMP_DIR."/ses");
file_remove_duplicates($TEMP_DIR."/upr");
file_remove_duplicates($TEMP_DIR."/user");

# List all objects
list_objects("APPL",$TEMP_DIR."/appl_lst",64);
list_objects("CLASS",$TEMP_DIR."/class_lst",64);
list_objects("DOM",$TEMP_DIR."/dom_lst",6);
list_objects("MU",$TEMP_DIR."/mu_lst",64);
list_objects("NODE",$TEMP_DIR."/node_lst",64);
list_objects("RES",$TEMP_DIR."/res_lst",64);
list_objects("SES",$TEMP_DIR."/ses_lst",64);
list_objects("UPR",$TEMP_DIR."/upr_lst",64);
list_objects("USER",$TEMP_DIR."/user_lst",64);

# Check if the dependencies exist
my $RESEXE = 0;
$RESEXE += check_object_exist($TEMP_DIR."/appl",$TEMP_DIR."/appl_lst","Application");
$RESEXE += check_object_exist($TEMP_DIR."/class",$TEMP_DIR."/class_lst","Class");
$RESEXE += check_object_exist($TEMP_DIR."/dom",$TEMP_DIR."/dom_lst","Domain");
$RESEXE += check_object_exist($TEMP_DIR."/mu",$TEMP_DIR."/mu_lst","MU");
$RESEXE += check_object_exist($TEMP_DIR."/node",$TEMP_DIR."/node_lst","Node");
$RESEXE += check_object_exist($TEMP_DIR."/ses",$TEMP_DIR."/ses_lst","Session");
$RESEXE += check_object_exist($TEMP_DIR."/res",$TEMP_DIR."/res_lst","Resource");
$RESEXE += check_object_exist($TEMP_DIR."/upr",$TEMP_DIR."/upr_lst","Uproc");
$RESEXE += check_object_exist($TEMP_DIR."/user",$TEMP_DIR."/user_lst","User");

# Cleanup
file_delete($TEMP_DIR."/appl_shw");
file_delete($TEMP_DIR."/appl_lst");
file_delete($TEMP_DIR."/appl");
file_delete($TEMP_DIR."/cal_shw");
file_delete($TEMP_DIR."/class_lst");
file_delete($TEMP_DIR."/class");
file_delete($TEMP_DIR."/dom_lst");
file_delete($TEMP_DIR."/dom");
file_delete($TEMP_DIR."/hdp_shw");
file_delete($TEMP_DIR."/mu_shw");
file_delete($TEMP_DIR."/mu_lst");
file_delete($TEMP_DIR."/mu");
file_delete($TEMP_DIR."/node_lst");
file_delete($TEMP_DIR."/node");
file_delete($TEMP_DIR."/res_lst");
file_delete($TEMP_DIR."/res");
file_delete($TEMP_DIR."/ses_shw");
file_delete($TEMP_DIR."/ses_lst");
file_delete($TEMP_DIR."/ses_shw_lnk");
file_delete($TEMP_DIR."/ses");
file_delete($TEMP_DIR."/tsk_shw");
file_delete($TEMP_DIR."/upr_shw");
file_delete($TEMP_DIR."/upr_lst");
file_delete($TEMP_DIR."/upr");
file_delete($TEMP_DIR."/user_lst");
file_delete($TEMP_DIR."/user");


# Return code
# 
print("\n");
print(" Objects missing: ".$RESEXE."\n");
print("\n");
exit $RESEXE;




### =============================================================================== ###
### Functions ###


## Exit in error because not the right script arguments
sub error_arguments {
    print(" Error: incorrect argment\n");
    print("   Expected argument: <AREA> <TARGET NODE>\n");
    print("   <AREA> (Optional): APP, INT, SIM, EXP\n");
    print("   <NODE> (Optional): Node to verify\n");
    exit 1;
}


## Check the dependency in a uxshw command
# Parameters
# 1- parameters
# 2- object
# 3- output file
sub list_dependencies {
    # Parameters
    my $file_in     = $_[0];
    my $dep_filter  = $_[1];
    my $out_file    = $_[2];
    
    my @OBJ_ARRAY;
    
    # Command
    open(FILE_IN, $file_in) or die("Could not open  file.");
    foreach $LINE (<FILE_IN>)  {
        if (index($LINE,$dep_filter)>-1) {
            my @TMP = split(':', $LINE);
            $TMP = @TMP[1];
            $TMP =~ s/ //g;
            if (length($TMP)>0) {
                $TMP =~ s/^\s+|\s+$//g;
                push(@OBJ_ARRAY, $TMP);
            }
        }
    }
    close(FILE_IN);
        
    # Remove duplicates
    @OBJ_ARRAY = uniq(@OBJ_ARRAY);
    
    # Output the result in a file
    open(FILE_OUT, ">>$out_file") or die "$!";;
    foreach my $TMP_OBJ (@OBJ_ARRAY) {
        print FILE_OUT $TMP_OBJ."\n";
    }
    close(FILE_OUT);

}


## List existing objects
# Parameters
# 1- parameters
# 2- object
# 3- output file
sub list_objects {
    # Parameters
    my $cmd_param   = $_[0];
    my $out_file    = $_[1];
    my $name_length = $_[2];
        
    # Command
    my $OBJ_LIST = `$ENV{'UNI_DIR_EXEC'}/uxlst $cmd_param $GCTX`;
    my @OBJ_LIST = split('\n', $OBJ_LIST);
    
    # Parse output and put in a file
    file_delete($out_file);
    open(FILE_OUT, '>>' , $out_file) or die "$!";;
    my $count = 0;
    foreach my $LINE (@OBJ_LIST) {
        $count++;
        if ($count>4) {
            $LINE=substr($LINE,0,$name_length);
            $LINE=~ s/^\s+|\s+$//g;
            print FILE_OUT $LINE."\n";
        }
    }
    close(FILE_OUT);

}


## Check if the objects in the files exists
# Parameters
# 1- name of the file
# 2- base command
# 3- name type of objects
# returns: number of objects missing
sub check_object_exist {
    # Parameters
    my $FILE_DEP   = $_[0];
    my $FILE_LST   = $_[1];
    my $OBJ_TYPE   = $_[2];

    my $NB_MISSING = 0;
    
    open(FILE_DEP, $FILE_DEP) or die("Could not open  file. ".$FILE_DEP);
    while( my $LINE = <FILE_DEP>) {
        # Remove end of line
        $LINE =~ s/\R//g;
        if (check_string_in_file($FILE_LST,$LINE)<0) {
            print(" ".$OBJ_TYPE." missing: ".$LINE."\n");
            $NB_MISSING++;
        }
    }
    close FILE_DEP;

    if ($NB_MISSING>0) {
        print("\n");
    }
    
    return $NB_MISSING
}


## Check if the a string exist in a file
# Parameters
# 1- name of the file
# 2- the string
# returns: 1 if found, -1 is not
sub check_string_in_file {
    # Parameters
    my $FILE_IN   = $_[0];
    my $STRING_S  = $_[1];    
    
    open(FILE_IN, $FILE_IN) or die("Could not open  file.");
    foreach $LINE (<FILE_IN>)  {
        $LINE =~ s/\R//g;
        if ($LINE eq $STRING_S) {
            return 1;
        }
    }
    close(FILE_IN);

    # Not found
    return -1;
}

## Remove duplicates in a
# Parameters
# 1- name of the file
sub file_remove_duplicates {
    # Parameters
    my $FILE_IN   = $_[0];
    
    my @OBJ_ARRAY;

    open(FILE_IN, $FILE_IN) or die("Could not open  file.");
    foreach $LINE (<FILE_IN>)  {
        $LINE =~ s/\R//g;
        push(@OBJ_ARRAY, $LINE);
    }
    close(FILE_IN);    
    
    # Parse output
    foreach my $LINE (@OBJ_LIST) {
        if (index($LINE,$dep_filter)>-1) {
            my @TMP = split(':', $LINE);
            $TMP = @TMP[1];
            $TMP =~ s/ //g;
            if (length($TMP)>0) {
                $TMP =~ s/^\s+|\s+$//g;
            }
        }
    }
    
    # Remove duplicates
    @OBJ_ARRAY = uniq(@OBJ_ARRAY);
    
    open(FILE_OUT, '>' , $FILE_IN) or die "$!";;
    foreach my $LINE (@OBJ_ARRAY) {
        $LINE =~ s/^\s+|\s+$//g;
        if (length($LINE)>0) {
            print FILE_OUT $LINE."\n";
        }
    }
    close(FILE_OUT);
}


## Remove the duplicates from the an array
# Parameters
# 1- The array to process
sub uniq {
    return keys %{{ map { $_ => 1 } @_ }};
}


## Delete a file
# 1. File
sub file_delete {
    my $file = $_[0];
    unlink($file);
}


## Store the uxshw 
# Parameters
# 1- parameters
# 2- output file
sub uxshw_store {
    # Parameters
    my $cmd_param   = $_[0];
    my $out_file    = $_[1];
    
    # Command
    my $OBJ_LIST = `$ENV{'UNI_DIR_EXEC'}/uxshw $cmd_param $GCTX`;
    my @OBJ_LIST = split('\n', $OBJ_LIST);
    
    # Parse output
    open(FILE_OUT, ">$out_file") or die "$!";;
    foreach my $LINE (@OBJ_LIST) {
        print FILE_OUT $LINE."\n";
    }
    close(FILE_OUT);
}



## Check the dependency in a uxshw command (specific to sessions)
# Parameters
# 1- parameters
# 3- output file
sub list_dependencies_session {
    # Parameters
    my $file_in     = $_[0];
    my $out_file    = $_[1];
    
    my @OBJ_ARRAY;
    
    # Command
    open(FILE_IN, $file_in) or die("Could not open  file.");
    foreach $LINE (<FILE_IN>)  {
        # Uproc in a session
        if (index($LINE," || ")>-1) {
            my @FIELDS= split(/\|/, $LINE);
            @FIELDS[7] =~ s/^\s+|\s+$//g;
            if ( (@FIELDS[7] ne "HDP/MU") && (substr(@FIELDS[7],0,1) ne "{") ) {
                push(@OBJ_ARRAY, @FIELDS[7]);
            }
        }
    }
    close(FILE_IN);
            
    # Remove duplicates
    @OBJ_ARRAY = uniq(@OBJ_ARRAY);
    
    # Output the result in a file
    open(FILE_OUT, ">>$out_file") or die "$!";;
    foreach my $TMP_OBJ (@OBJ_ARRAY) {
        print FILE_OUT $TMP_OBJ."\n";
    }
    close(FILE_OUT);
}
